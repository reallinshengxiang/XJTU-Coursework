from copy import deepcopy
import configs
import utils
import numpy as np
from matplotlib import pyplot as plt
from tqdm import tqdm

times=1001
tub_temp=deepcopy(configs.tub_temp)
hor=1
ver=0
draw=1

def init_param():
    water=configs.water()
    # print(water.T)
    for i in range(water.x):
        for j in range(water.y):
            if not in_rect(i,j):
                water.T[i,j]=0
            if not shape(i,j):
                water.flag[i,j]=0
    return water

if __name__=="__main__":
    if hor==1:
        water=configs.water()
        T=[]
        for time in tqdm(range(times)):
            temp=utils.tap_flow(water,time,overall_time=times)
            water=utils.process_velocity(temp,time)
            water,tub_temp=utils.process_temperature(water,time,tub_temp=tub_temp)
            T.append(cal_avg_temp(water))
            if time%200==0 and draw==1:
                plt.subplot(2,3,int(time/200)+1)
                plt.imshow(water.T,origin='lower',cmap='Wistia',interpolation='bicubic',vmin=30,vmax=45) # ,cmap='autumn_r',
                plt.colorbar()
                plt.title(str(time)+' ms')
                plt.xlabel('length/cm')
                plt.ylabel('width/cm')
        if draw==1:
            plt.show()
            plt.plot(T)
            plt.xlabel('Time / ms')
            plt.ylabel('Average temprature / ℃')
            plt.show()